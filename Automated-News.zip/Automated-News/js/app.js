$(function(){

    $(window).scroll(function(){
        if($(window).scrollTop() > 0){
            $(".header").addClass("sticky");
        }else {
            $(".header").removeClass("sticky");
        }
    });

    $('.icon-menu-mobile').on("click", function(){
        $('.mobile-menu').toggleClass('mobile-toggle');
    });

    $('.header-container .fas').on("click", function(){
        $('.mobile-menu').toggleClass('mobile-toggle');
    });

    $('.carousel').carousel({
        interval: 3500
    });    



});