//api images results link: https://api.scaleserp.com/search?api_key=8842DB260B7B46C6AF124D26BBA9F522&search_type=images&q=elon+musk&location_auto=true&hl=en

// "https://api.scaleserp.com/search?api_key=8842DB260B7B46C6AF124D26BBA9F522&search_type=images&q=" + saved_val + "&location_auto=true&hl=en"

$(function () {

    search_val = document.location.search.replace(/^.*?\=/, '');
    new_search_term = search_val.replace(/[^A-Za-z]+/g, ' ');
    $('.search').val(new_search_term);
    var search_term = $('.search').val();

    $('.search-container .fas').on("click", function () {

        if (!$('.search').val()) {
            alert("Please enter a search term!");
        } else {
            window.document.location = 'search-results.html' + '?search_query=' + $('.search').val();
        }
    });

    //navigate to news pg on click
    $('.news').on("click", function () {
        window.document.location = 'news-results.html' + '?search_query=' + search_term;
    });


    //navigate to images pg on click

    $('.images').on("click", function () {
        window.document.location = 'Images.html' + '?search_query=' + search_term;

    });

    var img_results = $.ajax({
        url: "https://api.scaleserp.com/search?api_key=8842DB260B7B46C6AF124D26BBA9F522&search_type=images&q=" + search_term + "&location_auto=true&hl=en",
        method: 'GET',
    });


    img_results.done((data) => {
        img_results = data;

        //fetch api data
        const fetch_imgs = () => {
            data.image_results.forEach(res => {

                result = `
                    <style>

                        .content {
                            display: inline-block;
                            margin: 10px 0 20px 0;
                        }

                        .content h5 {
                            font-size: 0.8rem;
                        }

                        .content h5:hover {
                            text-decoration: underline;
                        }

                        .content p {
                            font-size: 0.6rem;
                        }

                        .content p:hover {
                            text-decoration: underline;
                        }

                        .content img {
                            max-width: 354px;
                            max-height: 181px;
                        }

                        .content img:hover {
                            -webkit-box-shadow: 10px 10px 43px 0px rgba(0,0,0,0.75);
                            -moz-box-shadow: 10px 10px 43px 0px rgba(0,0,0,0.75);
                            box-shadow: 10px 10px 43px 0px rgba(0,0,0,0.75);
                        }

                        .modal {
                            display: none;
                            position: fixed;
                            z-index: 1;
                            left: 0;
                            top: 0;
                            width: 100%; /* Full width */
                            height: 100%; /* Full height */
                            overflow: auto; /* Enable scroll if needed */
                            background-color: rgb(0,0,0); /* Fallback color */
                            background-color: rgba(0,0,0,0.4); /* Black w/ opacity */
                        }
                        .modal-content {
                            background-color: #fefefe;
                            margin: 15% auto; /* 15% from the top and centered */
                            padding: 20px;
                            border: 1px solid #888;
                            width: 80%; /* Could be more or less, depending on screen size */
                        }
                        .modal-img {	
                            position: relative;
                            text-align: center;
                            max-width: 95%;
                            max-height: 20%;
                        }
                        .fa-share-alt-square {
                            font-size: 1.5rem; 
                            color: silver; 
                            padding-left: 20px;
                            pointer: cursor;
                        }
                        #close {
                            color: #aaa;
                            float: right;
                            font-size: 28px;
                            font-weight: bold;
                        }
                        #close:hover,
                        #close:focus {
                            color: black;
                            text-decoration: none;
                            cursor: pointer;
                        }


                        @media screen and (max-width: 425px){
                            .content {
                                display: grid;
                                width: 100%;
                                margin: 0;
                            }

                            .content img {
                                width: 100%;
                            }

                            .modal {
                                width: 100%;
                                height: 50%;
                            }

                            .modal-img {
                                width: 80%;
                                height: auto;
                            }

                        }
                    </style>
                    <div class="content">
                        
                        <img src="${res.image}">
                        <h5><a href="${res.link}"></a>${res.title}</h5>
                        <p><a href="${res.link}"></a>${res.domain}</p>
                    </div>
                    <div id="myModal" class="modal">
                        <div class="modal-content">
                            <i class="fas fa-times-circle" id="close"></i>
                            <img class="modal-img" src="${res.image}">
                            <i class="fas fa-share-alt-square" style=“font-size: 1.5rem; color: silver; padding-left: 20px;”></i>
                            <h3><a href="${res.link}"></a>${res.title}</h3>
                            <p>Images may be subject to copyright.</p>
                        </div>
                    </div>
                `


                $("#img-results").append(result);

            });

            var modal = document.getElementById("myModal");
            $('.content img').on("click", function () {
                var img_link = $(this).attr("src");
                $('.modal-img').attr("src", img_link);
                modal.style.display = "block";
                

            });


            $('#close').on("click", function () {
                modal.style.display = "none";
            });

            window.onclick = function (e) {
                if (e.target == modal) {
                    modal.style.display = "none";
                }
            }
        }

        fetch_imgs();
    });
});