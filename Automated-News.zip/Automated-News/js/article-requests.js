$(function(){

    const articleTitle = document.location.search.replace(/^.*?\=/,'');
    let new_title = articleTitle.replace(/[%0-9]/g, ' ');
    const image_link = localStorage.getItem('img_url');
    const article_link = localStorage.getItem('article_link');
    const article_content = localStorage.getItem('viewer_content');


    $('#title-1').text(new_title);
    $('#title-2').text(new_title);
    $('.mid1 .img-container').css('background', "url("+image_link+")");
    $('.bottom img').attr("src", image_link);
    $('.bottom a').attr("src", article_link);
    $('.bottom p').text(article_content);

    $('#working').text(img_link);

    localStorage.clear();

    $('.bottom a').on("click", function(){
        
        window.open(article_link);
    });
    //&.*$
});