//api organic search link : https://api.scaleserp.com/search?api_key=8842DB260B7B46C6AF124D26BBA9F522&q=elon+musk&location_auto=true&hl=en

// "https://api.scaleserp.com/search?api_key=8842DB260B7B46C6AF124D26BBA9F522&q="+ search_term + "&location_auto=true&hl=en"


$(function(){
    search_val = document.location.search.replace(/^.*?\=/,'');
    $('.search').val(search_val);
    var search_term = $('.search').val();
    var curr_pg = 1;

    $('.search-container .fas').on("click", function(){
        
        if(!$('.search').val()){
            alert("Please enter a search term!");
        }else{
            window.document.location = 'search-results.html' + '?search_query=' + search_term;
        }
    });

    //cpa offer on click
    $('.cpa-offer').on("click", function(){
        window.document.location = "https://afflat3e1.com/lnk.asp?o=5358&c=918277&a=409970&k=0698760976DA8C2E849BD3F78C6E2C3A&l=4125";
    });

    $('.cpa-offer2').on("click", function(){
        window.document.location = "https://afflat3e1.com/lnk.asp?o=5358&c=918277&a=409970&k=0698760976DA8C2E849BD3F78C6E2C3A&l=4125";
    });


    //navigate to news pg on click
    $('.news').on("click", function(){
        window.document.location = 'news-results.html' + '?search_query=' + search_term;
    });


    //navigate to images pg on click

    $('.images').on("click", function(){
        window.document.location = 'Images.html' + '?search_query=' + search_term;
        
    }); 

    var init = () => {
        var saved_val = localStorage.getItem('search-query');
        $('.search').val(saved_val);
        //"https://api.scaleserp.com/search?api_key=8842DB260B7B46C6AF124D26BBA9F522&q="+ search_term + "&location_auto=true&hl=en"
        var search_results = $.ajax({
            url: "https://api.scaleserp.com/search?api_key=8842DB260B7B46C6AF124D26BBA9F522&q="+ search_term + "&location_auto=true&hl=en",
            method: 'GET',
            
        });

        search_results.done((data)=>{
            display_results = data;

            //function to append result amount to element 
            const result_count = function(){
                let count = data.search_information.total_results;
                $('h4 .number').text(count);
            }

            //function to calculate & append how long it took results to appear
            const result_timer = () => {
                let timer = data.search_information.time_taken_displayed;
                $('h5 .time').text(timer);
            }

            

            //check if templates are supported
            const supportsTemplate = () => {
                if('content' in document.createElement('tpl')){
                    return "your browser does support template modules!";
                }
            }
            

            //function to loop through data
            
            const api_data = () => {

                
                //loop through api data
                data.organic_results.forEach(res => {
                    
                    result = `
                        <style>
                            .content {
                                -webkit-box-shadow: 10px 10px 5px 1px rgba(217,217,217,1);
                                -moz-box-shadow: 10px 10px 5px 1px rgba(217,217,217,1);
                                box-shadow: 10px 10px 5px 1px rgba(217,217,217,1);
                                width: 690px;
                                margin-bottom: 10px;
                                padding: 15px 10px 15px 10px;

                            }
                            .link {
                                font-size: 0.8rem;
                            }

                            .title {
                                font-size: 0.8rem;
                                color: rgb(35, 123, 39);
                            }


                            .descrip {
                                font-size: 0.8rem;
                            }                     
                        </style>
                        <div class="content">
                            <a class="link" href="${res.link}">${res.title}</a>
                            <h5 class="title">${res.link}</h5>
                            <p class="descrip">${res.snippet}</p>
                        </div>
                    `
                    
                    //append data to template
                    $("#search-results").append(result);
                });
                
            }

            //sort by function
            const sort_by = () => {
                $('.sort').change(function(){
                    if($("select option:nth(1)").is(":selected")){
                        location.reload();
                    }else if($("select option:nth(2)").is(":selected")){
                        location.reload();
                    }
                });
                
            }

            //when next button is clicked, paginate to next page results
            // "https://api.scaleserp.com/search?api_key=8842DB260B7B46C6AF124D26BBA9F522&q="+ search_term + "&location_auto=true&hl=en&page=" + curr_pg
            $('.next').on("click", function(){
                
                curr_pg++;
                
                var refresh_results = $.ajax({
                    url: "https://api.scaleserp.com/search?api_key=8842DB260B7B46C6AF124D26BBA9F522&q="+ search_term + "&location_auto=true&hl=en&page=" + curr_pg,
                    method: 'GET'
                });
                refresh_results.done((data)=>{
                    res = data;
                    location.reload();
                    api_data();
                });
                
            });
            

            //call functions here
            supportsTemplate();
            sort_by();
            api_data();
            result_count();
            result_timer();
            display_data();


            
        });

        


        
        var wikipedia_results = () => {
            var wiki_res = $.ajax({
                url: "http://en.wikipedia.org/w/api.php?action=query&list=search&srsearch=" +search_term+ "&format=json",
                method: 'GET'
            });
            wiki_res.done((data)=>{
                wiki_results = data;
                const append_data = (str, str2) => {
                    str2 = search_term.toUpperCase();
                    $("#wikipedia-results h3").text(str2.replace(/[^A-Za-z]+/g, ' '));
                    str = data.query.search[0].snippet;
                    $("#wikipedia-results .text-container p").text(str.replace(/<\/?[^>]+(>|$)/g, ""));
                }

                
                append_data();
                
            });

            var wiki_img = $.ajax({
                url: "https://pixabay.com/api/?key=18268357-6f0a025a913b99be84412de32&q="+ search_term +"&image_type=photo",
                method: 'GET'
            });

            wiki_img.done((data)=>{
                $('.wiki-img').attr("src", data.hits[0].largeImageURL);
            });
            
            
        };

        wikipedia_results();

        
    };

    init();

    

    

});