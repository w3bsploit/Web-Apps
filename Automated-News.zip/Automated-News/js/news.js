//api news results link: https://api.scaleserp.com/search?api_key=8842DB260B7B46C6AF124D26BBA9F522&search_type=news&q=elon+musk&location_auto=true&hl=en
// "https://api.scaleserp.com/search?api_key=8842DB260B7B46C6AF124D26BBA9F522&search_type=news&q=" + saved_val + "&location_auto=true&hl=en"

$(function(){

    search_val = document.location.search.replace(/^.*?\=/,'');
    $('.search').val(search_val);
    var search_term = $('.search').val();
    var curr_pg = 1;

    $('.search-container .fas').on("click", function(){
        
        if(!$('.search').val()){
            alert("Please enter a search term!");
        }else{
            window.document.location = 'search-results.html' + '?search_query=' + $('.search').val();
        }
    });

    //navigate to news pg on click
    $('.news').on("click", function(){
        window.document.location = 'news-results.html' + '?search_query=' + search_term;
    });


    //navigate to images pg on click

    $('.images').on("click", function(){
        window.document.location = 'Images.html' + '?search_query=' + search_term;
        
    });  
    //"https://api.scaleserp.com/search?api_key=8842DB260B7B46C6AF124D26BBA9F522&search_type=news&q=" + search_term + "&location_auto=true&hl=en"
    var news_display = $.ajax({
        url: "https://api.scaleserp.com/search?api_key=8842DB260B7B46C6AF124D26BBA9F522&search_type=news&q=" + search_term + "&location_auto=true&hl=en",
        method: 'GET',
    });

    news_display.done((data)=>{
        news_display = data;

        //function to append result amount to element 
        var result_total = function(){
            let count = data.search_information.total_results;
            $('h4 .number').text(count);
        }

        //function to calculate & append how long it took results to appear
        let time_displayed = () => {
            let timer = data.search_information.time_taken_displayed;
            $('h5 .time').text(timer);
        }

        //check if templates are supported
        const supportsTemplate = () => {
            if('content' in document.createElement('tpl')){
                return "your browser does support template modules!";
            }
        }

        const display_data = () => {
            //loop through api data
            data.news_results.forEach(res => {
                
                result = `
                    <style>
                        .content {
                            -webkit-box-shadow: 10px 10px 5px 1px rgba(217,217,217,1);
                            -moz-box-shadow: 10px 10px 5px 1px rgba(217,217,217,1);
                            box-shadow: 10px 10px 5px 1px rgba(217,217,217,1);
                            width: 690px;
                            margin-bottom: 10px;
                            padding: 15px 10px 15px 10px;

                        }
                        .link {
                            font-size: 0.8rem;
                        }

                        .title {
                            font-size: 0.8rem;
                            color: rgb(35, 123, 39);
                        }


                        .descrip {
                            font-size: 0.8rem;
                        }                     
                    </style>
                    <div class="content">
                        <a class="link" href="${res.link}">${res.title}</a>
                        <h5 class="title">${res.link}</h5>
                        <p class="descrip">${res.snippet}</p>
                    </div>
                `
                
                //append data to template
                $("#news-results").append(result);
            });
            
        }

        //when next button is clicked, paginate to next page results
        $('.next').on("click", function(){
           /* curr_pg++;
                
            var refresh_results = $.ajax({
                url: "https://api.scaleserp.com/search?api_key=8842DB260B7B46C6AF124D26BBA9F522&q="+ search_term + "&location_auto=true&hl=en&page=" + curr_pg,
                method: 'GET'
            });
            refresh_results.done((data)=>{
                res = data;
                location.reload();
                api_data();
            });*/
        });

        result_total();
        time_displayed();
        supportsTemplate();
        display_data();
    });
});